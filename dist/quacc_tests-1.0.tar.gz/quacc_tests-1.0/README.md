This project is to analyze the transition state calculations for the paper on NewtonNet and Sella calculations.

